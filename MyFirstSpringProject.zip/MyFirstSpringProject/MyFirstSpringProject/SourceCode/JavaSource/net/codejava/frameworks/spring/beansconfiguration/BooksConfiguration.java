package net.codejava.frameworks.spring.beansconfiguration;

import java.util.ArrayList;
import java.util.List;

import net.codejava.frameworks.spring.bo.Book;
import net.codejava.frameworks.spring.bo.Chapter;
import net.codejava.frameworks.spring.bo.Title;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

@Configuration
@Import(ChaptersConfiguration.class)
@PropertySource("classpath:beans.properties")
public class BooksConfiguration {

	@Autowired Environment env;
	
	@Autowired Title bookTitle;
	@Autowired Chapter chapter1;
	@Autowired Chapter chapter2;
	@Autowired Chapter chapter3;
	
	@Bean
	public Book myFirstSpringBook(){
		Book book = new Book();
		book.setIsbn(1);
		book.setAuthor(env.getProperty("myFirstSpringBook.author"));
		book.setTitle(bookTitle);
		List<Chapter> chapters = new ArrayList<Chapter>();
		chapters.add(chapter1);
		chapters.add(chapter2);
		chapters.add(chapter3);
		book.setChapters(chapters );
		return book;
	}

}
