package net.codejava.frameworks.spring.client.beanfactory;

import net.codejava.frameworks.spring.bo.Book;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;

public class XmlBeanFactoryClient {

	public static void main(String[] args) {

		// Classpath resource
		Resource resource1 = new ClassPathResource("beansWithValues.xml");
		BeanFactory beanFactory1 = new XmlBeanFactory(resource1);
		Book myFirstSpringBook1 = (Book) beanFactory1.getBean("myFirstSpringBook");
		System.out.println(myFirstSpringBook1.getTitle().getTitleValue());
		
		// File system resource
		Resource resource2 = new FileSystemResource("SourceCode/Config/beansWithValues.xml");
		BeanFactory beanFactory2 = new XmlBeanFactory(resource2);
		Book myFirstSpringBook2 = (Book) beanFactory2.getBean("myFirstSpringBook");
		System.out.println(myFirstSpringBook2.getTitle().getTitleValue());

	}

}
