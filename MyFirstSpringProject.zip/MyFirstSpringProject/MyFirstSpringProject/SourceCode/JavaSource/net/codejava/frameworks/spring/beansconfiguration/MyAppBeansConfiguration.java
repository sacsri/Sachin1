package net.codejava.frameworks.spring.beansconfiguration;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Import({TitlesConfiguration.class,ChaptersConfiguration.class,BooksConfiguration.class})
@Configuration
public class MyAppBeansConfiguration {

}
