package net.codejava.frameworks.spring.beansconfiguration;

import net.codejava.frameworks.spring.bo.Chapter;
import net.codejava.frameworks.spring.bo.Title;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

@Configuration
@Import(TitlesConfiguration.class)
@PropertySource("classpath:beans.properties")
public class ChaptersConfiguration {
	
	@Autowired Environment env;
	
	@Autowired Title chapter1Title;
	@Autowired Title chapter2Title;
	@Autowired Title chapter3Title;
	
	@Bean
	public Chapter chapter1(){
		// Injecting the dependencies using setter method
		Chapter chapter = new Chapter();
		chapter.setContent(env.getProperty("myFirstSpringBook.chapter1.content"));
		chapter.setNumber(1);
		chapter.setTitle(chapter1Title);
		return chapter;
	}

	@Bean
	public Chapter chapter2(){
		// Injecting the dependencies of chapter2 using constructor method
		return new Chapter(2,chapter2Title,env.getProperty("myFirstSpringBook.chapter2.content"));
	}

	@Bean
	public Chapter chapter3(){
		// Injecting the dependencies of chapter2 using constructor method
		return new Chapter(3,chapter3Title,env.getProperty("myFirstSpringBook.chapter3.content"));
	}
	
}
