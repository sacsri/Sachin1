package net.codejava.frameworks.spring.beansconfiguration;

import java.util.ArrayList;
import java.util.List;

import net.codejava.frameworks.spring.bo.Book;
import net.codejava.frameworks.spring.bo.Chapter;
import net.codejava.frameworks.spring.bo.Title;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class BeansConfiguration {
	
	@Bean
	public Title chapter1Title(){
		Title title = new Title();
		title.setTitleValue("Spring framework - Chapter 1");
		return title;
	}

	@Bean
	public Chapter chapter1(){
		Chapter chapter = new Chapter();
		chapter.setNumber(1);
		chapter.setContent("The content of chapter 1 goes here.");
		chapter.setTitle(chapter1Title());
		return chapter;
	}
	
	@Bean
	public Chapter chapter2(){
		return new Chapter(
				2,
				new Title("Spring framework - Chapter 2"), 
				"The content of chapter 2 goes here.");
	}
	
	@Bean
	public Title bookTitle(){
		Title title = new Title();
		title.setTitleValue("My first spring book");
		return title;
	}

	@Bean
	public Book myFirstSpringBook(){
		Book book = new Book();
		book.setIsbn(1);
		book.setAuthor("Mr. XYZ");
		book.setTitle(bookTitle());
		List<Chapter> chapters = new ArrayList<Chapter>();
		chapters.add(chapter1());
		chapters.add(chapter2());
		book.setChapters(chapters);
		return book;
	}
}
